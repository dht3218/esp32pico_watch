// template file - template_img_to_3d.c
// arrays declarations will be modified by python script ImgTo3D.py

#include "image_to_3d_matrix.h"

#ifdef CONFIG_3D_OBJECT_CUSTOM

const uint8_t TEMPLATE_ARRAY_BMP_IMAGE[NUM_OF_BYTES] = {};
const float TEMPLATE_ARRAY_IMAGE_TO_3D_MATRIX[NUM_OF_POINTS][4] = {};

#endif // CONFIG_3D_OBJECT_CUSTOM
