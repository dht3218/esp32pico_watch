#include "esp_dsp.h"
#include <malloc.h>

#include "unity.h"

#include "sdkconfig.h"
#include "dsp_tests.h"

void app_main()
{
    unity_run_menu();
}
